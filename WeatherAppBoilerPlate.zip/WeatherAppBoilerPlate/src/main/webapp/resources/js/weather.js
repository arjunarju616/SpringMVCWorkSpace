$(document).ready(function() {

	var monthNames = [ "January", "February", "March", "April",
						"May", "June", "July", "August", "September",
						"October", "November", "December" ];

    var time = 1508164035;
	var date = new Date(time * 1000);
	var month = date.getMonth();
	var todaysDate = date.getDate();
	var year = date.getFullYear();
	var getDate=monthNames[month] + " " + todaysDate + ", " + year;
	
	$("#SearchByCity").click(function(){
		var cityName=$("#CityName").val();
		if (!cityName.trim()) {
		   alert("Please Enter City Name");
		   return false;
		}
		 $.ajax({
		        url: "getWeatherByCityName",
		        data: {'cityName': cityName},
		        type: 'GET',
		        success: function (weatherData) {
		        	
		        	 $("#table_grid > tbody").empty();
		        	 $('#CityName').attr('value', '');  
		        	 $("#current_city_report").show();
		        	 var main=weatherData.main;
		        	 var wind=weatherData.wind;
		        	 var weather=weatherData.weather;
		        	 var htmlrow="<tr class='some_class_in_a_row_to_click'><td><img src='http://openweathermap.org/img/w/"+weather[0].icon+".png' width='50' height='50' alt='IMG' /></td><td><h4 class='title'>"+weatherData.name+"</h4><p class='date_content'>"+getDate+"</p></td><td><p class='weather_degrees'> <span class='degree'>"+main.temp+"&deg;C</span>"+" "+weather[0].main+"</p><p class='weather_content'>"+wind.speed+" m/s."+main.humidity+"%,"+main.pressure+" hpa</p></td><td><button class='btn btn-danger'>Delete</button></td><td class='some_class_for_column_with_data' hidden>"+weatherData.weatherDetailID+"</td></tr>";
		        	 $('#table_grid').append(htmlrow);
		        	
		        	
		        }
		    });
	})
	
	
	$("#ShowMore").click(function(){
		
		 $.ajax({
		        url: "getWeatherLogs",
		        type: 'GET',
		        success: function (weatherLogs) {
		        	
		        	$("#log_table_grid > tbody").empty();
		        	$("#city_log_report").show();
		        	var main;
		        	 var wind;
		        	 var weather;
		        	 var htmlrow='';
		        	
		        	 for (i = 0; i < weatherLogs.length; i++) { 
		        		  main=weatherLogs[i].main;
			        	  wind=weatherLogs[i].wind;
			        	  weather=weatherLogs[i].weather;
		        	      htmlrow="<tr class='some_class_in_a_row_to_clicklog'><td><img src='http://openweathermap.org/img/w/"+weather[0].icon+".png' width='50' height='50' alt='IMG' /></td><td><h4 class='title'>"+weatherLogs[i].name+"</h4><p class='date_content'>"+getDate+"</p></td><td><p class='weather_degrees'> <span class='degree'>"+main.temp+"&deg;C</span>"+" "+weather[0].main+"</p><p class='weather_content'>"+wind.speed+" m/s."+main.humidity+"%,"+main.pressure+" hpa</p></td><td><button class='btn btn-danger'>Delete</button></td><td class='some_class_for_column_with_datalog' hidden>"+weatherLogs[i].weatherDetailID+"</td></tr>";
		        	      $('#log_table_grid').append(htmlrow);
		        	 }
		        	 
		        }
		    });
		 })
		 
		 
		 
	 $("#ShowLess").click(function(){
		 $("#city_log_report").hide();
	 });
	
	$('#table_grid .some_class_in_a_row_to_click').live('click', function(){
	      var column = $(this).find('.some_class_for_column_with_data');
	      var weatherDetailID = column.text();
	      alert(weatherDetailID);
	      $.ajax({
		        url: "deleteCityLog",
		        data: {'weatherDetailID': weatherDetailID},
		        type: 'GET',
		        success: function (weatherData) {
		        	$("#current_city_report").hide();
		        	alert("Successfully Deleted");
		         },
		        error: function (error) {
		            alert("Error Occurred While Deteling");
		        }
		    });
	  
	});
	
	$('#log_table_grid .some_class_in_a_row_to_clicklog').live('click', function(){
		     
		      var column = $(this).find('.some_class_for_column_with_datalog');
		      var weatherDetailID = '1';//column.text();
		      alert(weatherDetailID);
		      $.ajax({
			        url: "deleteCityLog",
			        data: {'weatherDetailID': weatherDetailID},
			        type: 'GET',
			        success: function (weatherData) {
			        	$('#ShowMore').trigger('click');
			        	alert("Successfully Deleted");
			         },
			        error: function (error) {
			            alert("Error Occurred While Deteling");
			        }
		    });
		      
		});
				
})