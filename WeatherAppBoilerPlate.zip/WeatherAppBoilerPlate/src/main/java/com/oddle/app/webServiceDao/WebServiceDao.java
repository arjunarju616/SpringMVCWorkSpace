package com.oddle.app.webServiceDao;

import org.springframework.stereotype.Service;

import com.oddle.app.model.Weatherdetails;

@Service
public interface WebServiceDao {

	public Weatherdetails getWeatherByCityName(String cityName);
}
