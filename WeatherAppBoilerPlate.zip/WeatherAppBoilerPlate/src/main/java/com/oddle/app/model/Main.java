package com.oddle.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="main")
public class Main {

	@Id
	@Column(name = "mainid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer mainid;
	
	@Column(name = "temp")
	private Double temp;
	
	@Column(name = "pressure")
	private Integer pressure;
	
	@Column(name = "humidity")
	private Integer humidity;
	
	@Column(name = "tempMin")
	private Double tempMin;
	
	@Column(name = "tempMax")
	private Double tempMax;

	public Integer getMainid() {
		return mainid;
	}

	public void setMainid(Integer mainid) {
		this.mainid = mainid;
	}

	public Double getTemp() {
		return temp;
	}

	public void setTemp(Double temp) {
		this.temp = temp;
	}

	public Integer getPressure() {
		return pressure;
	}

	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}

	public Integer getHumidity() {
		return humidity;
	}

	public void setHumidity(Integer humidity) {
		this.humidity = humidity;
	}

	public Double getTempMin() {
		return tempMin;
	}

	public void setTempMin(Double tempMin) {
		this.tempMin = tempMin;
	}

	public Double getTempMax() {
		return tempMax;
	}

	public void setTempMax(Double tempMax) {
		this.tempMax = tempMax;
	}

}
