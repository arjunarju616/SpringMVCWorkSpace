package com.oddle.app.webServiceInvocation;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oddle.app.controller.WeatherController;
import com.oddle.app.model.Weatherdetails;
import com.oddle.app.openWeatherMapConstants.WeatherMapConsntants;
import com.oddle.app.webServiceDao.WebServiceDao;
import com.oddle.app.webServices.WebServices;

@Service

public class WebServiceInvocation implements WebServices {
	
	@Autowired
	WebServiceDao webServiceDao;
	
	@Override
	public Weatherdetails getWeatherByCityName(String cityName) {
		
		return webServiceDao.getWeatherByCityName(cityName);
		
	}

}
