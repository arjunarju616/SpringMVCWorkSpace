package com.oddle.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="clouds")
public class Clouds {
	
	@Id
	@Column(name = "cloudid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cloudid;
	
	@Column(name = "all")
	private Integer all;
	

	public Integer getCloudid() {
		return cloudid;
	}

	public void setCloudid(Integer cloudid) {
		this.cloudid = cloudid;
	}

	public Integer getAll() {
		return all;
	}

	public void setAll(Integer all) {
		this.all = all;
	}

}
