package com.oddle.app.WebServiceDaoImpl;

import java.net.URL;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oddle.app.controller.WeatherController;
import com.oddle.app.model.Weatherdetails;
import com.oddle.app.openWeatherMapConstants.WeatherMapConsntants;
import com.oddle.app.webServiceDao.WebServiceDao;


@Service
public class WebServiceDaoImpl implements WebServiceDao{

	private static final Logger logger = Logger.getLogger(WeatherController.class);
	@Override
	public Weatherdetails getWeatherByCityName(String cityName) {
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		Weatherdetails weatherObj = null;
		try {
			logger.info("----------Entered getWeatherByCityName Method -----------");
			/*
			 * obj = mapper .readValue( new URL(
			 * "http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b1b15e88fa797225412429c1c50c122a1"
			 * ), Weatherdetails.class);
			 */

			weatherObj = mapper.readValue(new URL(WeatherMapConsntants.OPEN_MAP_URI),
					Weatherdetails.class);
		
		//	Date date = new Date((long)weatherObj.getDt()*1000);
			//Date date1=date;

		} catch (Exception e) {
			logger.error("Threw an exceprion from getWeatherByCityName: ",e);
		}
		
		logger.info("----------getWeatherByCityName Method exitted -----------");
		return weatherObj;
	}

}
