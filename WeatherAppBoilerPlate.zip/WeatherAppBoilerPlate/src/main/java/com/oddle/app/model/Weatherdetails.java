package com.oddle.app.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.IndexColumn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)


@Entity
@Table(name="weatherdetails")
public class Weatherdetails {
	
	Weatherdetails(){
		this.addedDate=new Date();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "weatherDetailID")
	private Integer weatherDetailID;
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Coord coord;
	
	//(cascade = CascadeType.ALL)
//	@JoinColumn(name="weatherDetailID",referencedColumnName="weatherDetailFk",nullable=false)
	 // @OneToMany(mappedBy="troop")
	//@JoinColumn(name = "weatherDetailID",referencedColumnName="weatherDetailFk")
	//@JoinColumn(name = "weatherDetailID")
	//@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL,CascadeType.PERSIST,CascadeType.MERGE }, mappedBy = "weatherdetails")
   // @Column(nullable = false)
	//@OneToMany(cascade = CascadeType.ALL)
	/*@OneToMany(mappedBy="weatherdetails" ,cascade = CascadeType.ALL)
	@JoinTable(name = "weatherdetails")*/
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy="weatherdetails")
  //  @JoinColumn(name = "w_id")
	private Set<Weather> weather = null;
	
	@Column(name = "base")
	private String base;
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Main main;
	
	@Column(name = "visibility")
	private Integer visibility;
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Wind wind;
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Clouds clouds;
	
	@Column(name = "dt")
	private Integer dt;
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Sys sys;
	
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "cod")
	private Integer cod;
	
	@Column(name = "addedDate")
	private Date addedDate;

	public Coord getCoord() {
		return coord;
	}

	public void setCoord(Coord coord) {
		this.coord = coord;
	}

	

	public Set<Weather> getWeather() {
		return weather;
	}

	public void setWeather(Set<Weather> weather) {
		this.weather = weather;
	}

	public String getBase() {
		return base;
	}

	public void setBase(String base) {
		this.base = base;
	}

	public Main getMain() {
		return main;
	}

	public void setMain(Main main) {
		this.main = main;
	}

	public Integer getVisibility() {
		return visibility;
	}

	public void setVisibility(Integer visibility) {
		this.visibility = visibility;
	}

	public Wind getWind() {
		return wind;
	}

	public void setWind(Wind wind) {
		this.wind = wind;
	}

	public Clouds getClouds() {
		return clouds;
	}

	public void setClouds(Clouds clouds) {
		this.clouds = clouds;
	}

	public Integer getDt() {
		return dt;
	}

	public void setDt(Integer dt) {
		this.dt = dt;
	}

	public Sys getSys() {
		return sys;
	}

	public void setSys(Sys sys) {
		this.sys = sys;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getCod() {
		return cod;
	}

	public void setCod(Integer cod) {
		this.cod = cod;
	}

	public Integer getWeatherDetailID() {
		return weatherDetailID;
	}

	public void setWeatherDetailID(Integer weatherDetailID) {
		this.weatherDetailID = weatherDetailID;
	}

	public Date getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(Date addedDate) {
		this.addedDate = addedDate;
	}
	
	

}
