package com.oddle.app.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oddle.app.model.Weather;
import com.oddle.app.model.Weatherdetails;

@Service
public interface WeatherDao {

        public int saveWeatherLog(Weatherdetails weatherdetail);
	    
	    public List<Weatherdetails> getWeatherLogs();
	 
	    public boolean deleteWeatherLog(int weatherlogid);

		
	}


