package com.oddle.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="wind")
public class Wind {

	@Id
	@Column(name = "windid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer windid;
	
	@Column(name = "speed")
	private Double speed;
	
	@Column(name = "deg")
	private Integer deg;

	public Integer getWindid() {
		return windid;
	}

	public void setWindid(Integer windid) {
		this.windid = windid;
	}

	public Double getSpeed() {
		return speed;
	}

	public void setSpeed(Double speed) {
		this.speed = speed;
	}

	public Integer getDeg() {
		return deg;
	}

	public void setDeg(Integer deg) {
		this.deg = deg;
	}

}
