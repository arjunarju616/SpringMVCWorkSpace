package com.oddle.app.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import com.oddle.app.dao.WeatherDao;
import com.oddle.app.model.Weatherdetails;
import com.oddle.app.service.WeatherService;
import com.oddle.app.webServices.WebServices;

@Controller
@Component
@RequestMapping("/")
public class WeatherController {
	private static final Logger logger = Logger.getLogger(WeatherController.class);

	@Autowired
	WeatherService weatherService;

	@Autowired
	WebServices webService;

	@RequestMapping(value = "weather", method = RequestMethod.GET)
	public String getHomePage(Model model) {

		try {
			logger.info("----------Entered getHomePage Method-----------");

			model.addAttribute("message", "This is a boilerplate project");

		} catch (Exception e) {
			logger.error("Threw an exception from getHomePagemethod: ", e);

		}
		logger.info("---------getHomePage Method Exitted--------");
		return "weather";
	}
	

	@RequestMapping(value = "getWeatherByCityName", method = RequestMethod.GET)
	public @ResponseBody Weatherdetails getWeatherByCityName(@RequestParam String cityName) {

		Weatherdetails weatherData = null;
		try {
			logger.info("----------Entered getWeatherByCityName Method-----------");

			if (cityName != null && !cityName.trim().isEmpty()) {
				weatherData = webService.getWeatherByCityName(cityName);
				int WeatherDetailID = weatherService.saveWeatherLog(weatherData);
				weatherData.setWeatherDetailID(WeatherDetailID);
			//	weatherService.saveWeatherLog(weatherData);
				
				
			} else {
				return null;
			}

		//	model.addAttribute("weatherData", weatherData);
		} catch (Exception e) {
			logger.error("Threw an exception from getWeatherByCityName: ", e);
		}

		logger.info("----------getWeatherByCityName Method Exitted-----------");
		return weatherData;
	}
	
	@RequestMapping(value = "getWeatherLogs", method = RequestMethod.GET)
	public @ResponseBody List<Weatherdetails> getWeatherLogs() {
		Weatherdetails weatherData1 = null;
		Weatherdetails weatherData2 = null;
		List<Weatherdetails> weatherDatalog = new ArrayList<Weatherdetails>();
		try {
			logger.info("----------Entered getWeatherByCityName Method-----------");

			//weatherData = weatherService.getWeatherLogs();
			weatherData1=webService.getWeatherByCityName("2r34");
					weatherData2=webService.getWeatherByCityName("2r34");
			weatherDatalog.add(weatherData1);
			weatherDatalog.add(weatherData2);
				
			

		} catch (Exception e) {
			logger.error("Threw an exception from getWeatherByCityName: ", e);
		}

		logger.info("----------getWeatherByCityName Method Exitted-----------");
		return weatherDatalog;
	}
	
	
	
	@RequestMapping(value = "deleteCityLog", method = RequestMethod.GET)
	public @ResponseBody boolean deleteCityLog(@RequestParam int weatherDetailID) {
		boolean bool= false;
		try {
			logger.info("----------Entered getWeatherByCityName Method-----------");

			//weatherData = weatherService.getWeatherLogs();
			bool= weatherService.deleteWeatherLog(weatherDetailID);
			

		} catch (Exception e) {
			logger.error("Threw an exception from getWeatherByCityName: ", e);
		}

		logger.info("----------getWeatherByCityName Method Exitted-----------");
		return true;
	}
}
