package com.oddle.app.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="weather")
public class Weather {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "weatherid", nullable=false,insertable=false, updatable=false)
	private Integer weatherid;
	
/*	@Column(name = "weatherDetailFk",nullable=false,insertable=false, updatable=false)
	private Integer weatherDetailFk;*/
	
	@Column(name = "id")
	private Integer id;
	
	

	public Integer getWeatherid() {
		return weatherid;
	}

	public void setWeatherid(Integer weatherid) {
		this.weatherid = weatherid;
	}

	@Column(name = "main")
	private String main;
	
	@Column(name = "description")
	private String description;

	@Column(name = "icon")
	private String icon;
	
	@ManyToOne
	@JoinColumn(name = "weatherDetailID", nullable = false)
	private Weatherdetails weatherdetails;
	
	

	/*public Integer getWeatherDetailFk() {
		return weatherDetailFk;
	}

	public void setWeatherDetailFk(Integer weatherDetailFk) {
		this.weatherDetailFk = weatherDetailFk;
	}*/

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}
	
	public Weatherdetails getWeatherdetails() {
		return weatherdetails;
	}

	public void setWeatherdetails(Weatherdetails weatherdetails) {
		this.weatherdetails = weatherdetails;
	}

}
