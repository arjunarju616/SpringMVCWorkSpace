package com.oddle.app.openWeatherMapConstants;

public final class WeatherMapConsntants {
	
	private WeatherMapConsntants(){
		
	}
	
		  //public static final String OPEN_MAP_URI ="http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b1b15e88fa797225412429c1c50c122a1";
				  //final URL"http://api.openweathermap.org/data/2.5/weather?q=Bangalore&appid=8a4e84762ae509d7a81e4c765cf905b7&units=metric";
	public static final String OPEN_MAP_URI="http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b1b15e88fa797225412429c1c50c122a1";
		  public static final String APPID = "8a4e84762ae509d7a81e4c765cf905b7";
		}