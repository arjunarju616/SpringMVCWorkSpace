package com.oddle.app.daoImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.oddle.app.controller.WeatherController;
import com.oddle.app.dao.WeatherDao;
import com.oddle.app.model.Weather;
import com.oddle.app.model.Weatherdetails;


@Repository
@Transactional
@EnableTransactionManagement
public class WeatherDaoImpl implements WeatherDao {

	private static final Logger logger = Logger.getLogger(WeatherDaoImpl.class);
	
	@Autowired
    SessionFactory session;
	
	@Override
	public int saveWeatherLog(Weatherdetails weatherdetails) {
		
		int WeatherDetailID=0;
		try{
		logger.info("----------Entered saveWeatherLog Method-----------");
		session.getCurrentSession().save(weatherdetails);
		
		System.out.println("after save : user id's = "+weatherdetails.getWeatherDetailID() );
        WeatherDetailID=weatherdetails.getWeatherDetailID();
		}catch(Exception e){
			logger.error("Threw an exception from saveWeatherLog: ",e);
		}
		
		logger.info("----------saveWeatherLog Method Exitted-----------");
		return WeatherDetailID;
	}

	@Override
	public List<Weatherdetails> getWeatherLogs() {
		
		List<Weatherdetails> weatherdetaillist=null;
		try{
			logger.info("----------Entered getWeatherLogs Method-----------");
			
			 weatherdetaillist=(List<Weatherdetails>)session.getCurrentSession().createQuery("from weatherdetails where addedDate < (SELECT MAX(addedDate) FROM weatherdetails) group by weatherdetails.name ").list();
			}catch(Exception e){
				logger.error("Threw an exception from getWeatherLogs: ",e);
			}
			
			logger.info("----------getWeatherLogs Method Exitted-----------");
			
		return weatherdetaillist;
	}

	@Override
	public boolean deleteWeatherLog(int weatherlogid) {
		boolean success=false;
		try{
			logger.info("----------Entered deleteWeatherLog Method-----------");
			
			session.getCurrentSession().createQuery("delete from weatherdetails where weatherDetailID = :weatherDetailID").setParameter("weatherDetailID", weatherlogid);
			success=true;
			}catch(Exception e){
				logger.error("Threw an exception from deleteWeatherLog: ",e);
			}
			
			logger.info("----------deleteWeatherLog Method Exitted-----------");
			
        return success;
	}

}
