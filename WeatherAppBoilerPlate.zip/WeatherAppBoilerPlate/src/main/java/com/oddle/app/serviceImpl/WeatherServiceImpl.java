package com.oddle.app.serviceImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.oddle.app.controller.WeatherController;
import com.oddle.app.dao.WeatherDao;
import com.oddle.app.model.Weather;
import com.oddle.app.model.Weatherdetails;
import com.oddle.app.service.WeatherService;

@Service

public class WeatherServiceImpl implements WeatherService {

	 @Autowired
	 WeatherDao weatherDao;
	 
	@Override
	public int saveWeatherLog(Weatherdetails weatherdetail) {
		
		return weatherDao.saveWeatherLog(weatherdetail);
	}

	@Override
	public List<Weatherdetails> getWeatherLogs() {
		
		return null;
	}

	@Override
	public boolean deleteWeatherLog(int weatherlogid) {
		
		return weatherDao.deleteWeatherLog(weatherlogid);
	}

}
