package com.oddle.app.webServices;

import org.springframework.stereotype.Service;

import com.oddle.app.model.Weatherdetails;

@Service
public interface WebServices {
	
	public Weatherdetails getWeatherByCityName(String cityName);

}
