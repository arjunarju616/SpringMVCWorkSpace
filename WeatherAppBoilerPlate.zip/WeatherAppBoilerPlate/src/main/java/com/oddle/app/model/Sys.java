package com.oddle.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sys")
public class Sys {

	@Id
	@Column(name = "sysid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sysid;
	
	@Column(name = "type")
	private Integer type;
	
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "message")
	private Double message;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "sunrise")
	private Integer sunrise;
	
	@Column(name = "sunset")
	private Integer sunset;

	public Integer getSysid() {
		return sysid;
	}

	public void setSysid(Integer sysid) {
		this.sysid = sysid;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getMessage() {
		return message;
	}

	public void setMessage(Double message) {
		this.message = message;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getSunrise() {
		return sunrise;
	}

	public void setSunrise(Integer sunrise) {
		this.sunrise = sunrise;
	}

	public Integer getSunset() {
		return sunset;
	}

	public void setSunset(Integer sunset) {
		this.sunset = sunset;
	}

}
