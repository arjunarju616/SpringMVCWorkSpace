package com.oddle.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="coord")
public class Coord {
	
	@Id
	@Column(name = "coordid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer coordid;
	
	@Column(name = "lon")
	private Double lon;
	
	@Column(name = "lat")
	private Double lat;

	public Integer getCoordid() {
		return coordid;
	}

	public void setCoordid(Integer coordid) {
		this.coordid = coordid;
	}

	public Double getLon() {
		return lon;
	}

	public void setLon(Double lon) {
		this.lon = lon;
	}

	public Double getLat() {
		return lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}

}
