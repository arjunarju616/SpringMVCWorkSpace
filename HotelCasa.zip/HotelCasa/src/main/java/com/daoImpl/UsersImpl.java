package com.daoImpl;
 
import java.util.List;

import javax.servlet.FilterRegistration.Dynamic;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dao.UsersDao;
import com.entities.Users;
 
@Repository

public class UsersImpl implements UsersDao {
 
    @Autowired
    SessionFactory session;
 
    public boolean saveOrUpdate(Users users) {
    //	session.getCurrentSession().
    	
        //session.getCurrentSession().saveOrUpdate(users);
        session.getCurrentSession().save(users);
        return true;
    }
    
    public Integer getLastUserId() {
        
    	List lst=session.getCurrentSession().createQuery("from Users").list();
    	int count=lst.size();
        return count;
    }
    public boolean getUsers(String email) {
        Boolean bool=false;
    	List lst= session.getCurrentSession().createQuery("from Users where email = :email").setParameter("email", email).list();
    	if(lst.isEmpty()){
    		bool=true;
        
    	}else{
    		bool=false;
    	}
    	return bool;
    }
 
    public List<Users> list() {
    	 //arj=session.getCurrentSession().createQuery("from Users").list();
    Users usr=	(Users) session.getCurrentSession().get(Users.class,1);
        return session.getCurrentSession().getNamedQuery("findEmployeeByName").list() ; //getCurrentSession().createQuery("findEmployeeByName").list();
    }
 
    public boolean delete(Users users) {
        try {
            session.getCurrentSession().delete(users);
        } catch (Exception ex) {
            return false;
        }
 
        return true;
    }
}