package com.controllers;
 
import java.awt.image.BufferedImage;
import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 






import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
 






import com.entities.Users;
import com.services.UsersService;
 
@Controller
@RequestMapping("users")
public class UsersController {
 
    @Autowired
    UsersService userServices;
 
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String getIndexPage(Model model) {
    	 model.addAttribute("index", new Users()); 
      
        return "index";
    }
    
    @RequestMapping(value = "/about-us", method = RequestMethod.GET)
    public ModelAndView getAboutUsPage() {
        ModelAndView view = new ModelAndView("about-us");
        return view;
    }
    
    @RequestMapping(value = "/contact-us", method = RequestMethod.GET)
    public ModelAndView getContactUsPage() {
        ModelAndView view = new ModelAndView("contact-us");
        return view;
    }
    
    @RequestMapping(value = "/home-2", method = RequestMethod.GET)
    public ModelAndView gethome2() {
        ModelAndView view = new ModelAndView("home-2");
        return view;
    }
    
    @RequestMapping(value = "/home-3", method = RequestMethod.GET)
    public ModelAndView gethome3() {
        ModelAndView view = new ModelAndView("home-3");
        return view;
    }
    
    @RequestMapping(value = "/privacy-policy", method = RequestMethod.GET)
    public ModelAndView getPrivacyPolicy() {
        ModelAndView view = new ModelAndView("privacy-policy");
        return view;
    }
    
  /*  @RequestMapping(value = "/properties-listing-grid", method = RequestMethod.GET)
    public ModelAndView getPropertiesListingGrid() {
        ModelAndView view = new ModelAndView("properties-listing-grid");
        return view;
    }*/
    
    @RequestMapping(value = "/properties-listing-list", method = RequestMethod.GET)
    public ModelAndView getPropertiesListingList() {
        ModelAndView view = new ModelAndView("properties-listing-list");
        return view;
    }
    
    @RequestMapping(value = "/property-details-book", method = RequestMethod.GET)
    public ModelAndView getPropertyDetailsBook() {
        ModelAndView view = new ModelAndView("property-details-book");
        return view;
    }
    
    @RequestMapping(value = "/property-details-rent", method = RequestMethod.GET)
    public ModelAndView getPropertyDetailsRent() {
        ModelAndView view = new ModelAndView("property-details-rent");
        return view;
    }
    
    @RequestMapping(value = "/property-details-swap", method = RequestMethod.GET)
    public ModelAndView getPropertyDetailsSwap() {
        ModelAndView view = new ModelAndView("property-details-swap");
        return view;
    }
    
    @RequestMapping(value = "/shortcodes", method = RequestMethod.GET)
    public ModelAndView getShortcodes() {
        ModelAndView view = new ModelAndView("shortcodes");
        return view;
    }
    
    @RequestMapping(value = "/terms-conditions", method = RequestMethod.GET)
    public ModelAndView getTermsConditions() {
        ModelAndView view = new ModelAndView("terms-conditions");
        return view;
    }
    
    @RequestMapping(value = "/favicon", method = RequestMethod.GET)
    public ModelAndView getFavicon() {
        ModelAndView view = new ModelAndView("favicon");
        return view;
    }
 
    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public ModelAndView getSaved(Users users) throws IOException {
        Map<String, Object> map = new HashMap<String, Object>();
 
        if (userServices.getUsers(users)) {
        	userServices.saveOrUpdate(users);
        }
        ModelAndView view = new ModelAndView("terms-conditions");
        return view;
    }
 
    @RequestMapping(value = "/properties-listing-grid", method = RequestMethod.GET)
    public ModelAndView getPropertiesListingGrid() {
        Map<String, Object> map = new HashMap<String, Object>();
 
        List<Users> list = userServices.list();
 
        ModelAndView view = new ModelAndView("properties-listing-grid");
        view.addObject("list",list);
        return view;
    }
 
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public @ResponseBody Map<String, Object> delete(Users users) {
        Map<String, Object> map = new HashMap<String, Object>();
 
        if (userServices.delete(users)) {
            map.put("status", "200");
            map.put("message", "Your record have been deleted successfully");
        }
 
        return map;
    }
}