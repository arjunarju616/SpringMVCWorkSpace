package com.controllers;
import java.sql.*;
import java.util.ArrayList;

import com.entities.Users;

public class JdbcConnection {
	
	public static void main(String args[]){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=  DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelcasa","root","root");
			
			Statement stmt=conn.createStatement();
			ResultSet st=stmt.executeQuery("select * from users");
			CallableStatement cal=conn.prepareCall("{call userlist()}");
			cal.execute();
			int columnCount=st.getRow();
			ArrayList<Users> hotelResultList = new ArrayList<>(columnCount); 
		//	Users usr= new Users();
			while(st.next()){
				Users usr= new Users();
			usr.setUserId(st.getString(1));	//st.getString(1);
			usr.setUserName(st.getString(2));//	st.getString(2);
				usr.setEmail(st.getString(3));//st.getString(3);
				usr.setPassword( st.getString(4));// st.getString(4);
				Object element = st.next();
				hotelResultList.add(usr);
			}
			int index=0;
			String arr[]=new String[hotelResultList.size()];
			for (Object value : hotelResultList) {
				arr[index] = (String) value;
				  index++;
				}
			System.out.println("arjun");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
