package com.controllers;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entities.UserLogin;
import com.entities.Users;
import com.google.gson.JsonObject;
import com.mysql.fabric.xmlrpc.base.Array;


	@Controller
	public class collections
	{
		@RequestMapping(value = "/employees")
		public @ResponseBody Users getAllEmployees()
		{String arj="arjun";
		char[] ret=arj.toCharArray();
		
			String[] arr= {"a","b"};
			int[] arr1={1,2,3};
		String reversed=	new StringBuilder(arj).reverse().toString();
		
			char[] arr2={'a','f'};
			Users employees = new Users();
			employees.setPassword("drgfwe");
			employees.setUserId("b");
			employees.setEmail("aertg");
			employees.setUserName("evt");
			//Add employees
			return employees;
		}
		
		public static void main(String args[]){
			collections coll= new collections();
		//JsonObject son=	coll.getAllEmployees();
		}
	}

