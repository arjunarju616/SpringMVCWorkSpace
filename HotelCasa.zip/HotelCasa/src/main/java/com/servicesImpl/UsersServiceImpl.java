package com.servicesImpl;
 
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.dao.UsersDao;
import com.entities.Users;
import com.services.UsersService;
 
@Service
@Transactional
@EnableTransactionManagement
public class UsersServiceImpl implements UsersService {
 
    @Autowired
    UsersDao userDao;
 
    public boolean saveOrUpdate(Users users) {
    	Calendar now = Calendar.getInstance();   // Gets the current date and time
    	int year = now.get(Calendar.YEAR); 
    	int usercount=userDao.getLastUserId();
    	
    	String userId ="HC"+year+usercount;
    	users.setUserId(userId);
    	
        return userDao.saveOrUpdate(users);
    }
    public boolean getUsers(Users users) {
        String email=users.getEmail();
        return userDao.getUsers(email);
    }
 
    public List<Users> list() {
        // TODO Auto-generated method stub
        return userDao.list();
    }
 
    public boolean delete(Users users) {
        // TODO Auto-generated method stub
        return userDao.delete(users);
    }
 
}